class PasswordTools {
    static togglePasswordVisibility(input, toggle) {
        if (input && toggle) {
            if (input.type === 'password') {
                input.type = 'text';
                toggle.textContent = 'visibility_off';
            } else {
                input.type = 'password';
                toggle.textContent = 'visibility';
            }
        }
    }

    static async updatePasswordStrength(password) {
        if (!password) return;

        const strength = zxcvbn(password);
        const availableStrengthText = ['Very weak', 'Weak', 'Common', 'Strong', 'Very strong.'];
        const strengthText = availableStrengthText[strength.score];
        let strengthFeedback = ''
        if (strength.feedback.suggestions.length) {
            strengthFeedback = ', ' + strength.feedback.suggestions.join(' ');
        }
        $('#password-strength-text').html(
            `<span style="color: var(--strength-${strength.score});font-weight:bold;">${strengthText}</span>
            ${strengthFeedback}`
        );
        $('#password-strength').attr('class', `password-strength strength-${strength.score}`);
    }

    static async updatePasswordBreach(password) {
        if (!password) return;

        const data = new TextEncoder().encode(password);
        const hashBuffer = await crypto.subtle.digest('SHA-1', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
        const prefix = hashHex.substring(0, 5);
        const suffix = hashHex.substring(5);
        const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
        const result = await response.text();
        const lines = result.split('\n');
        
        let breachResult = { breached: false, count: 0 };
        for (const line of lines) {
            const [lineSuffix, count] = line.trim().split(':');
            if (lineSuffix === suffix) {
                breachResult = { breached: true, count: parseInt(count) };
                break;
            }
        }
        
        if (breachResult.breached) {
            $('#breach-alert').show().text(`⚠️ This password has been seen ${breachResult.count.toLocaleString()} times before in data breaches!`).css('color', '#ff4b5c');
        } else {
            $('#breach-alert').show().text('✅ This password has not been found in any known breaches at present and can be used.').css('color', '#66bb6a');
        }
    }

    static updateHintedColor(password) {
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            hash = (hash << 5) - hash + password.charCodeAt(i);
            hash |= 0;
        }
        const hashHex = Math.abs(hash).toString(16).padStart(6, '0');
        const num = parseInt(hashHex.slice(0, 6), 16);
        const index = num % 5;
        return index;
    }
}

export { PasswordTools };