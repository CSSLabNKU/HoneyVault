class Storage {
    static localSave(key, value) {
        return new Promise((resolve) => {
            chrome.storage.local.set({ [key]: value }, resolve);
        });
    }

    static localGet(key) {
        return new Promise((resolve) => {
            chrome.storage.local.get(key, (result) => {
                resolve(key in result ? result[key] : null);
            });
        });
    }

    static localRemove(key) {
        return new Promise((resolve) => {
            chrome.storage.local.remove(key, resolve);
        });
    }

    static localClear() {
        return new Promise((resolve) => {
            chrome.storage.local.clear(resolve);
        });
    }

    static sessionSave(key, value) {
        return new Promise((resolve) => {
            chrome.storage.session.set({ [key]: value }, resolve);
        });
    }

    static sessionGet(key) {
        return new Promise((resolve) => {
            chrome.storage.session.get(key, (result) => {
                resolve(key in result ? result[key] : null);
            });
        });
    }

    static sessionRemove(key) {
        return new Promise((resolve) => {
            chrome.storage.session.remove(key, resolve);
        });
    }

    static sessionClear() {
        return new Promise((resolve) => {
            chrome.storage.session.clear(resolve);
        });
    }
}

export { Storage };
