class Notifications {
    constructor() {
        this.iconMap = {
            success: 'check_circle',
            error: 'error',
            warning: 'warning',
            info: 'info'
        };
        this.activeOverlay = null;
        this.init();
    }
    
    init() {
        // Create stylesheet link if not exists
        if (!document.querySelector('link[href*="notification.css"]')) {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = '../style/notification.css';
            document.head.appendChild(link);
        }
        
        // Create notification container if not exists
        let notificationContainer = document.getElementById('notification-container');
        if (!notificationContainer) {
            notificationContainer = document.createElement('div');
            notificationContainer.id = 'notification-container';
            document.body.appendChild(notificationContainer);
        }
    }

    showNotification(message, type = 'info', duration = 0) {
        // Create overlay
        this.showOverlay();
        
        // Get or create notification container
        let notificationContainer = document.getElementById('notification-container');
        if (!notificationContainer) {
            // Double check in case init hasn't run or container was removed
            notificationContainer = document.createElement('div');
            notificationContainer.id = 'notification-container';
            document.body.appendChild(notificationContainer);
        }        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        
        notification.innerHTML = `
            <div class="notification-icon">
            <span class="material-icons">${this.iconMap[type] || 'info'}</span>
            </div>
            <div class="notification-message">${message}</div>
            <div class="notification-close">
            <span class="material-icons">close</span>
            </div>
        `;

        notificationContainer.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 10);

        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.addEventListener('click', () => {
            this.closeNotification(notification);
        });

        // Only auto-close if duration is specifically provided and greater than 0
        if (duration > 0) {
            setTimeout(() => {
            this.closeNotification(notification);
            }, duration);
        }
        
        return notification;
        }

    showOverlay() {
        if (!this.activeOverlay) {
            this.activeOverlay = document.createElement('div');
            this.activeOverlay.className = 'overlay';
            document.body.appendChild(this.activeOverlay);
            
            // Prevent body scrolling
            document.body.style.overflow = 'hidden';
            
            // Add click handler to close on overlay click (optional)
            this.activeOverlay.addEventListener('click', () => {
                const notifications = document.querySelectorAll('.notification');
                if (notifications.length > 0) {
                    // Close the last notification when clicking overlay
                    this.closeNotification(notifications[notifications.length - 1]);
                }
            });
        }
    }
        
    hideOverlay() {
        const container = document.getElementById('notification-container');
        if (this.activeOverlay && (!container || container.children.length <= 1)) {
            this.activeOverlay.remove();
            this.activeOverlay = null;
            
            // Re-enable body scrolling
            document.body.style.overflow = '';
        }
    }

    closeNotification(notification) {
        notification.classList.remove('show');
        notification.classList.add('hide');
        
        setTimeout(() => {
            notification.remove();
            this.hideOverlay();
        }, 300);
    }

    showSuccess(message, duration = 0) {
        return this.showNotification(message, 'success', duration);
    }

    showError(message, duration = 0) {
        return this.showNotification(message, 'error', duration);
    }

    showWarning(message, duration = 0) {
        return this.showNotification(message, 'warning', duration);
    }

    showInfo(message, duration = 0) {
        return this.showNotification(message, 'info', duration);
    }
    }

export const notifications = new Notifications();
