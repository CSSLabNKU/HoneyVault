class Crypto{
    static async deriveKey(password, salt, iterations = 11000, keyLength = 256) {
        const encoder = new TextEncoder();
        const passwordBuffer = encoder.encode(password);
        const baseKey = await window.crypto.subtle.importKey(
            'raw',
            passwordBuffer,
            'PBKDF2',
            false,
            ['deriveKey']
        );
        const cryptoKey = await window.crypto.subtle.deriveKey(
            {
                name: 'PBKDF2',
                salt: salt,
                iterations: iterations,
                hash: 'SHA-256'
            },
            baseKey,
            {
                name: 'AES-CTR',
                length: keyLength
            },
            true,
            ['encrypt', 'decrypt']
        );
        return cryptoKey;
    }

    static async encrypt(cryptoKey, iv, data, bitLength=128) {
        const dataBytes = await Crypto.bigIntListToBytes(bitLength, data);
        const encryptedData = await window.crypto.subtle.encrypt(
            {
                name: 'AES-CTR',
                counter: iv,
                length: 64
            },
            cryptoKey,
            dataBytes
        );
        return Array.from(new Uint8Array(encryptedData));
    }

    static async decrypt(cryptoKey, iv, ciphertext, size=100, bitLength=128) {
        const decryptedBuffer = await window.crypto.subtle.decrypt(
            {
                name: 'AES-CTR',
                counter: iv,
                length: 64
            },
            cryptoKey,
            new Uint8Array(ciphertext)
        );
        const bytes = new Uint8Array(decryptedBuffer);
        return await Crypto.bytesToBigIntList(bitLength, bytes, size);
    }

    static async bigIntListToBytes(bitLength, bigIntList) {
        const byteLength = bitLength / 8;
        const dataBytes = new Uint8Array(bigIntList.length * byteLength);

        bigIntList.forEach((bigInt, index) => {
            const bytes = new Uint8Array(byteLength);
            let temp = bigInt;
            for (let i = byteLength - 1; i >= 0; i--) {
            bytes[i] = Number(temp & 0xffn);
            temp >>= 8n;
            }
            dataBytes.set(bytes, index * byteLength);
        });
        return dataBytes;
    }

    static async bytesToBigIntList(bitLength, bytes, size) {
        const result = [];
        const byteLength = bitLength / 8;
        for (let i = 0; i < size; i++) {
            const slice = bytes.slice(i * byteLength, (i + 1) * byteLength);
            result.push(
            slice.reduce((acc, curr) => (acc << 8n) + BigInt(curr), 0n)
            );
        }
        return result;
    }

    static generateSalt(length = 32) {
        return window.crypto.getRandomValues(new Uint8Array(length));
    }

    static generateCounter(length = 16) {
        return window.crypto.getRandomValues(new Uint8Array(length));
    }

    static async exportKeyAsBase64(cryptoKey) {
        const keyBuffer = await window.crypto.subtle.exportKey('raw', cryptoKey);
        return btoa(String.fromCharCode(...new Uint8Array(keyBuffer)));
    }

    static async importKeyFromBase64(base64String) {
        const binaryString = atob(base64String);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return await window.crypto.subtle.importKey(
            'raw',
            bytes,
            { name: 'AES-CTR' }, 
            false,
            ['encrypt', 'decrypt']
        );
    }
}

export { Crypto };