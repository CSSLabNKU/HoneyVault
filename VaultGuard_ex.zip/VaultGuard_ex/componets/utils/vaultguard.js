import { Crypto } from './crypto.js';

function randomBigInt(max) {
    if (max <= 0n) return 0n;
    const bytes = Math.ceil(max.toString(2).length / 8);
    let rand;
    do {
        let arr = new Uint8Array(bytes);
        if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
            window.crypto.getRandomValues(arr);
        } else {
            for (let i = 0; i < bytes; i++) arr[i] = Math.floor(Math.random() * 256);
        }
        rand = 0n;
        for (let b of arr) rand = (rand << 8n) + BigInt(b);
    } while (rand >= max);
    return rand;
}

class DTE {
    constructor(l) {
        this.l = l;
        this.MAX_INT = (1n << BigInt(l)) - 1n;
    }

    // 生成 num 个 [0, MAX_INT) 的均匀分布大整数
    padding(num) {
        const arr = [];
        for (let i = 0; i < num; i++) {
            arr.push(randomBigInt(this.MAX_INT));
        }
        return arr;
    }

    // 概率值 a ∈ [0,1] 映射到 [0, MAX_INT]
    rep(a) {
        if (a < 0) a = 0;
        if (a > 1) a = 1;
        return BigInt(Math.floor(Number(this.MAX_INT) * a));
    }

    encode(m, cdf) {
        cdf = [0, ...cdf];
        m = m + 1;
        const left = this.rep(cdf[m-1]);
        const right = this.rep(cdf[m]) - 1n;
        if (right <= left) throw new Error('CDF 区间无效');
        return left + randomBigInt(right - left);
    }

    decode(s, cdf) {
        cdf = [0, ...cdf];
        for (let m = 1; m < cdf.length; m++) {
            if (this.rep(cdf[m]) > s) {
                return m - 1;
            }
        }
    }
}

function indexToPrev(idx, n, charset) {
    const k = charset.length;
    let totalSoFar = 0;
    if (idx === 0) {
        return ' '.repeat(n);
    }
    totalSoFar = 1;
    for (let len = 1; len <= n; len++) {
        const countInThisLayer = Math.pow(k, len);
        const startIdx = totalSoFar;
        const endIdx = totalSoFar + countInThisLayer - 1;
        if (idx >= startIdx && idx <= endIdx) {
            const localIdx = idx - startIdx;
            let shortStr = "";
            let current = localIdx;
            for (let i = 0; i < len; i++) {
                const digit = current % k;
                shortStr = charset[digit] + shortStr;
                current = Math.floor(current / k);
            }
            return ' '.repeat(n - len) + shortStr;
        }
        totalSoFar += countInThisLayer;
    }
    throw new Error(`Index ${idx} out of bound [0, ${totalSoFar - 1}]`);
}

function prevToIndex(s, n, charset) {
    if (s.length !== n) {
        throw new Error("The length of the string must be equal to n");
    }
    const k = charset.length;
    let totalSoFar = 0;
    if (s === ' '.repeat(n)) {
        return 0;
    }
    const trimmed = s.trimStart();
    const len = trimmed.length;
    if (len === 0) {
        throw new Error("The string cannot be all spaces (already handled) or contain invalid spaces");
    }
    if (len > n) {
        throw new Error("Invalid string length");
    }
    const leadingSpaces = n - len;
    if (!s.startsWith(' '.repeat(leadingSpaces))) {
        throw new Error("The leading part must be spaces");
    }
    let localIdx = 0;
    for (let i = 0; i < len; i++) {
        const char = trimmed[i];
        const digitValue = charset.indexOf(char);
        if (digitValue === -1) {
            throw new Error(`Character '${char}' not found in charset`);
        }
        const weight = Math.pow(k, len - 1 - i);
        localIdx += digitValue * weight;
    }
    totalSoFar = 1;
    for (let l = 1; l < len; l++) {
        totalSoFar += Math.pow(k, l);
    }
    return totalSoFar + localIdx;
}

class Encoder {
    constructor(charset, length_counts, prpm, sppm) {
        this.dte = new DTE(128);
        this.order = 4;
        this.start = " ";
        this.pseudocount = 0.001;
        this.MINLEN = 6;
        this.MAXLEN = 30;
        this.charset = charset
        this.MAXCODELEN = 100;
        this.length_counts = length_counts
        this.length_cdf = this.pdf2cdf(Object.values(this.length_counts));
        this.idx2len = Object.keys(this.length_counts).map(len => Number(len));
        this.len2idx = Object.fromEntries(this.idx2len.map((len, idx) => [len, idx]));
        this.uniform_chars_cdf = this.pdf2cdf(Array.from(this.charset).map(() => 1));
        this.prpm = prpm;
        this.sppm = sppm;
    }

    adaptive(pdf, ngrams) {
        for (let i = 0; i < ngrams.length; i++) {
            const next = ngrams[i][1];
            const nextIdx = this.charset.indexOf(next);
            pdf[nextIdx] = pdf[nextIdx] * 2;
        }
        return pdf;
    }

    sppmParse(password) {
        const l = String(password).length;
        if (l < this.min_pw_len || l > this.max_pw_len) throw new Error('Length out of bounds.');
        const rules = [l];
        let pw = this.start.repeat(this.order) + password;
        for (let i = this.order; i < pw.length; i++) {
            const prev = pw.slice(i - this.order, i);
            const next = pw[i];
            rules.push([prev, next]);
        }
        return rules;
    }

    sppmGenerate(rules) {
        return rules.slice(1).map(r => r[1]).join('');
    }

    sppmEncode(rules, ngrams) {
        let length = rules[0];
        const lenIdx = this.len2idx[length];
        let codes = [this.dte.encode(lenIdx, this.length_cdf)];
        const bos = this.start.repeat(this.order);

        for (let i = 2; i < rules.length; i++) {
            const [prev, next] = rules[i];
            const previdx = prevToIndex(prev, this.order, this.charset);

            let cdf = this.uniform_chars_cdf;
            if (this.sppm[length] && this.sppm[length][previdx]) {
                let pdf = [];
                for (let c of this.charset) {
                    pdf.push((this.sppm[length][previdx][c] || 0) + this.pseudocount);
                }
                if (bos == prev) {
                    pdf = this.adaptive(pdf, ngrams);
                }
                cdf = this.pdf2cdf(pdf);
            }

            const nextIdx = this.charset.indexOf(next);
            codes.push(this.dte.encode(nextIdx, cdf));
        }

        if (codes.length < this.MAXCODELEN) {
            codes = codes.concat(this.dte.padding(this.MAXCODELEN - codes.length));
        }
        return codes;
    }

    sppmDecode(codes, ngrams, fixed) {
        let idx = 0;
        const lenIdx = this.dte.decode(codes[idx++], this.length_cdf);
        const length = this.idx2len[lenIdx];
        const bos = this.start.repeat(this.order);
        let rules = [length];

        let pw = this.start.repeat(this.order) + fixed;
        rules.push([pw.slice(0, this.order), fixed]);
        for (let i = 1; i < parseInt(length); i++) {
            const prev = pw.slice(i, i + this.order);
            const prevIdx = prevToIndex(prev, this.order, this.charset);

            let cdf = this.uniform_chars_cdf;
            if (this.sppm && this.sppm[length] && this.sppm[length][prevIdx]) {
                let pdf = [];
                for (let c of this.charset) {
                    pdf.push((this.sppm[length][prevIdx][c] || 0) + this.pseudocount);
                }
                if (bos == prev) {
                    pdf = this.adaptive(pdf, ngrams);
                }
                cdf = this.pdf2cdf(pdf);
            }

            const nextIdx = this.dte.decode(codes[idx++], cdf);
            const next = this.charset[nextIdx];
            rules.push([prev, next]);
            pw += next;
        }
        return rules;
    }

    LCSStr(s1, s2) {
        let maxLen = 0;
        let endPos = 0;
        let prevRow = Array(s2.length + 1).fill(0);
        for (let i = 1; i <= s1.length; i++) {
            const currRow = Array(s2.length + 1).fill(0);
            for (let j = 1; j <= s2.length; j++) {
                if (s1[i - 1] === s2[j - 1]) {
                    currRow[j] = prevRow[j - 1] + 1;
                    if (currRow[j] > maxLen) {
                        maxLen = currRow[j];
                        endPos = i - 1;
                    }
                }
            }
            prevRow = currRow;
        }
        return maxLen === 0 ? "" : s1.slice(endPos - maxLen + 1, endPos + 1);
    }

    isReuse(bw, pw) {
        const lcs = this.LCSStr(bw, pw);
        const max_len = Math.max(bw.length, pw.length);
        return lcs.length > (max_len / 2);
    }

    multiReuse(vault) {
        const excludedIdx = new Set();
        const reused = [];
        for (let idx = 0; idx < vault.length; idx++) {
            if (excludedIdx.has(idx)) continue;
            
            excludedIdx.add(idx);
            const bw = vault[idx];

            for (let candidate = idx + 1; candidate < vault.length; candidate++) {
                if (excludedIdx.has(candidate)) continue;

                const pw = vault[candidate];
                if (this.prpmParse(bw, pw)) {
                    excludedIdx.add(candidate);
                    reused.push([candidate, idx]);
                }
            }
        }

        reused.sort((a, b) => a[0] - b[0]);
        return reused; // [[reusedIdx, baseIdx], ...]
    }

    reuseCheck(index, reused) {
        for (const [reusedIdx, baseIdx] of reused) {
            if (index === reusedIdx) {
                return baseIdx; // return the index of bw of the reused pw 
            }
        }
        return null; // there is no reuse
    }

    prpmParse(bw, pw) {
        if (!this.isReuse(bw, pw)) {
            return null;
        }

        const lcsstr = this.LCSStr(bw, pw);
        const bw_start = bw.indexOf(lcsstr);
        const pw_start = pw.indexOf(lcsstr);
        const bw_end = bw_start + lcsstr.length;
        const pw_end = pw_start + lcsstr.length;
        
        const rules = {"H": null, "T": null};
        
        const h_del_size = bw_start;
        const h_add_char = pw.substring(0, pw_start);
        const h_add_size = h_add_char.length;
        const head_ops = {
            "MOD": "None", 
            "HDN": 0, 
            "HAN": 0, 
            "HAC": []
        };
        if (h_del_size > 0 && h_add_size > 0) {
            head_ops["MOD"] = "Delete-Add";
            head_ops["HDN"] = h_del_size;
            head_ops["HAN"] = h_add_size;
            head_ops["HAC"] = Array.from(h_add_char);
        } 
        else if (h_del_size > 0 && h_add_size === 0) {
            head_ops["MOD"] = "Delete";
            head_ops["HDN"] = h_del_size;
        } 
        else if (h_del_size === 0 && h_add_size > 0) {
            head_ops["MOD"] = "Add";
            head_ops["HAN"] = h_add_size;
            head_ops["HAC"] = Array.from(h_add_char);
        }
        rules["H"] = head_ops;
        
        const t_del_size = bw.length - bw_end;
        const t_add_char = pw.substring(pw_end);
        const t_add_size = t_add_char.length;
        const tail_ops = {
            "MOD": "None", 
            "TDN": 0, 
            "TAN": 0, 
            "TAC": []
        };
        if (t_del_size > 0 && t_add_size > 0) {
            tail_ops["MOD"] = "Delete-Add";
            tail_ops["TDN"] = t_del_size;
            tail_ops["TAN"] = t_add_size;
            tail_ops["TAC"] = Array.from(t_add_char);
        } 
        else if (t_del_size > 0 && t_add_size === 0) {
            tail_ops["MOD"] = "Delete";
            tail_ops["TDN"] = t_del_size;
        } 
        else if (t_del_size === 0 && t_add_size > 0) {
            tail_ops["MOD"] = "Add";
            tail_ops["TAN"] = t_add_size;
            tail_ops["TAC"] = Array.from(t_add_char);
        }
        rules["T"] = tail_ops;
        
        return rules;
    }

    prpmGenerate(bw, rules) {
        const head_ops = rules["H"];
        const tail_ops = rules["T"];
        let pw = this.modifyHead(bw, head_ops);
        pw = this.modifyTail(pw, tail_ops);
        return pw;
    }

    prpmEncode(bw, rules) {
        let codes = [];
        const len_bw = bw.length;
        
        const head_ops = rules["H"];
        const tail_ops = rules["T"];

        // Encode HDN
        const hdn = head_ops["HDN"] || 0;
        const MAX_HDN = Math.floor(len_bw / 2);
        const valid_HDN = this.getValidDistribution(this.prpm.HDN, MAX_HDN);
        const valid_HDN_cdf = this.pdf2cdf(Object.values(valid_HDN));
        const hdn_idx = Object.keys(valid_HDN).indexOf(hdn.toString());
        codes.push(this.dte.encode(hdn_idx, valid_HDN_cdf));

        // Encode TDN
        const tdn = tail_ops["TDN"] || 0;
        const MAX_TDN = Math.floor(len_bw / 2) - hdn;
        const valid_TDN = this.getValidDistribution(this.prpm.TDN, MAX_TDN);
        const valid_TDN_cdf = this.pdf2cdf(Object.values(valid_TDN));
        const tdn_idx = Object.keys(valid_TDN).indexOf(tdn.toString());
        codes.push(this.dte.encode(tdn_idx, valid_TDN_cdf));

        // Encode HAN
        const han = head_ops["HAN"] || 0;
        const MAX_HAN = len_bw - hdn - tdn;
        const valid_HAN = this.getValidDistribution(this.prpm.HAN, MAX_HAN);
        const valid_HAN_cdf = this.pdf2cdf(Object.values(valid_HAN));
        const han_idx = Object.keys(valid_HAN).indexOf(han.toString());
        codes.push(this.dte.encode(han_idx, valid_HAN_cdf));

        // Encode TAN
        const tan = tail_ops["TAN"] || 0;
        const MAX_TAN = len_bw - hdn - tdn - han;
        const valid_TAN = this.getValidDistribution(this.prpm.TAN, MAX_TAN);
        const valid_TAN_cdf = this.pdf2cdf(Object.values(valid_TAN));
        const tan_idx = Object.keys(valid_TAN).indexOf(tan.toString());
        codes.push(this.dte.encode(tan_idx, valid_TAN_cdf));

        // Encode HAC
        const reversedHAC = [...head_ops["HAC"]].reverse();
        for (let j = 0; j < reversedHAC.length; j++) {
            const c = reversedHAC[j];
            const c_idx = this.charset.indexOf(c);
            let HAC_pdf = [];
            for (let c of this.charset) {
                HAC_pdf.push(this.prpm['HAC'][c]);
            }
            
            if (j === 0 && j < hdn) {
                const d_c_idx = this.charset.indexOf(bw[hdn - j - 1]);
                HAC_pdf = [...HAC_pdf]; // Create a copy
                HAC_pdf[d_c_idx] = 0;
                const HAC_cdf = this.pdf2cdf(HAC_pdf);
                codes.push(this.dte.encode(c_idx, HAC_cdf));
            } else {
                const HAC_cdf = this.pdf2cdf(HAC_pdf);
                codes.push(this.dte.encode(c_idx, HAC_cdf));
            }
        }

        // Encode TAC
        for (let j = 0; j < tail_ops["TAC"].length; j++) {
            const c = tail_ops["TAC"][j];
            const c_idx = this.charset.indexOf(c);
            let TAC_pdf = [];
            for (let c of this.charset) {
                TAC_pdf.push(this.prpm['TAC'][c]);
            }
            
            if (j === 0 && j < tdn) {
                const c_d_idx = this.charset.indexOf(bw[len_bw - tdn + j]);
                TAC_pdf = [...TAC_pdf]; // Create a copy
                TAC_pdf[c_d_idx] = 0;
                const TAC_cdf = this.pdf2cdf(TAC_pdf);
                codes.push(this.dte.encode(c_idx, TAC_cdf));
            } else {
                const TAC_cdf = this.pdf2cdf(TAC_pdf);
                codes.push(this.dte.encode(c_idx, TAC_cdf));
            }
        }

        // Pad to fixed length
        if (codes.length < this.MAXCODELEN) {
            codes = codes.concat(this.dte.padding(this.MAXCODELEN - codes.length));
        }
        return codes;
    }

    prpmDecode(bw, codes) {
        const len_bw = bw.length;
        const rules = {
            "H": {"MOD": "None", "HDN": 0, "HAN": 0, "HAC": []},
            "T": {"MOD": "None", "TDN": 0, "TAN": 0, "TAC": []}
        };

        // Decode HDN
        const MAX_HDN = Math.floor(len_bw / 2);
        const valid_HDN = this.getValidDistribution(this.prpm.HDN, MAX_HDN);
        const valid_HDN_cdf = this.pdf2cdf(Object.values(valid_HDN));
        const hdn_idx = this.dte.decode(codes.shift(), valid_HDN_cdf);
        const hdn = Object.keys(valid_HDN)[hdn_idx];
        rules["H"]["HDN"] = parseInt(hdn);

        // Decode TDN
        const MAX_TDN = Math.floor(len_bw / 2) - rules["H"]["HDN"];
        const valid_TDN = this.getValidDistribution(this.prpm.TDN, MAX_TDN);
        const valid_TDN_cdf = this.pdf2cdf(Object.values(valid_TDN));
        const tdn_idx = this.dte.decode(codes.shift(), valid_TDN_cdf);
        const tdn = Object.keys(valid_TDN)[tdn_idx];
        rules["T"]["TDN"] = parseInt(tdn);

        // Decode HAN
        const MAX_HAN = len_bw - rules["H"]["HDN"] - rules["T"]["TDN"];
        const valid_HAN = this.getValidDistribution(this.prpm.HAN, MAX_HAN);
        const valid_HAN_cdf = this.pdf2cdf(Object.values(valid_HAN));
        const han_idx = this.dte.decode(codes.shift(), valid_HAN_cdf);
        const han = Object.keys(valid_HAN)[han_idx];
        rules["H"]["HAN"] = parseInt(han);

        // Decode TAN
        const MAX_TAN = len_bw - rules["H"]["HDN"] - rules["T"]["TDN"] - rules["H"]["HAN"];
        const valid_TAN = this.getValidDistribution(this.prpm.TAN, MAX_TAN);
        const valid_TAN_cdf = this.pdf2cdf(Object.values(valid_TAN));
        const tan_idx = this.dte.decode(codes.shift(), valid_TAN_cdf);
        const tan = Object.keys(valid_TAN)[tan_idx];
        rules["T"]["TAN"] = parseInt(tan);

        // Decode HAC
        rules["H"]["HAC"] = [];
        for (let j = 0; j < rules["H"]["HAN"]; j++) {
            let HAC_pdf = [];
            for (let c of this.charset) {
                HAC_pdf.push(this.prpm['HAC'][c]);
            }
            if (j === 0 && j < rules["H"]["HDN"]) {
                const d_c_idx = this.charset.indexOf(bw[rules["H"]["HDN"] - j - 1]);
                HAC_pdf = [...HAC_pdf]; // Create a copy
                HAC_pdf[d_c_idx] = 0;
                const HAC_cdf = this.pdf2cdf(HAC_pdf);
                const c_idx = this.dte.decode(codes.shift(), HAC_cdf);
                const c = this.charset[c_idx];
                rules["H"]["HAC"].unshift(c);
            } else {
                const HAC_cdf = this.pdf2cdf(HAC_pdf);
                const c_idx = this.dte.decode(codes.shift(), HAC_cdf);
                const c = this.charset[c_idx];
                rules["H"]["HAC"].unshift(c);
            }
        }

        // Decode TAC
        rules["T"]["TAC"] = [];
        for (let j = 0; j < rules["T"]["TAN"]; j++) {
            let TAC_pdf = [];
            for (let c of this.charset) {
                TAC_pdf.push(this.prpm['TAC'][c]);
            }
            if (j === 0 && j < rules["T"]["TDN"]) {
                const c_d_idx = this.charset.indexOf(bw[len_bw - rules["T"]["TDN"] + j]);
                TAC_pdf = [...TAC_pdf]; // Create a copy
                TAC_pdf[c_d_idx] = 0;
                const TAC_cdf = this.pdf2cdf(TAC_pdf);
                const c_idx = this.dte.decode(codes.shift(), TAC_cdf);
                const c = this.charset[c_idx];
                rules["T"]["TAC"].push(c);
            } else {
                const TAC_cdf = this.pdf2cdf(TAC_pdf);
                const c_idx = this.dte.decode(codes.shift(), TAC_cdf);
                const c = this.charset[c_idx];
                rules["T"]["TAC"].push(c);
            }
        }

        // Set M based on the results of decoded H and T
        if (rules["H"]["HDN"] === 0 && rules["H"]["HAN"] === 0) {
            rules["H"]["MOD"] = "None";
        }
        if (rules["H"]["HDN"] > 0 && rules["H"]["HAN"] === 0) {
            rules["H"]["MOD"] = "Delete";
        }
        if (rules["H"]["HDN"] === 0 && rules["H"]["HAN"] > 0) {
            rules["H"]["MOD"] = "Add";
        }
        if (rules["H"]["HDN"] > 0 && rules["H"]["HAN"] > 0) {
            rules["H"]["MOD"] = "Delete-Add";
        }

        if (rules["T"]["TDN"] === 0 && rules["T"]["TAN"] === 0) {
            rules["T"]["MOD"] = "None";
        }
        if (rules["T"]["TDN"] > 0 && rules["T"]["TAN"] === 0) {
            rules["T"]["MOD"] = "Delete";
        }
        if (rules["T"]["TDN"] === 0 && rules["T"]["TAN"] > 0) {
            rules["T"]["MOD"] = "Add";
        }
        if (rules["T"]["TDN"] > 0 && rules["T"]["TAN"] > 0) {
            rules["T"]["MOD"] = "Delete-Add";
        }

        return rules;
    }

    modifyHead(pw, head_ops) {
        switch (head_ops["MOD"]) {
            case "None":
                return pw;
            case "Delete":
                return pw.slice(head_ops["HDN"]);
            case "Add":
                return head_ops["HAC"].join("") + pw;
            case "Delete-Add":
                return head_ops["HAC"].join("") + pw.slice(head_ops["HDN"]);
            default:
                return pw;
        }
    }

    modifyTail(pw, tail_ops) {
        switch (tail_ops["MOD"]) {
            case "None":
                return pw;
            case "Delete":
                return pw.slice(0, -tail_ops["TDN"] || undefined);
            case "Add":
                return pw + tail_ops["TAC"].join("");
            case "Delete-Add":
                return pw.slice(0, -tail_ops["TDN"] || undefined) + tail_ops["TAC"].join("");
            default:
                return pw;
        }
    }

    getValidDistribution(distribution, max_value) {
        const valid_distribution = {};
        for (const [key, value] of Object.entries(distribution)) {
            if (parseInt(key) <= max_value) {
                valid_distribution[key] = value;
            }
        }
        return valid_distribution;
    }

    pdf2cdf(pdf) {
        let acc = 0;
        const sum = pdf.reduce((a, b) => a + b, 0);
        return pdf.map(x => (acc += x) / sum);
    }
}



class VaultGuard {
    constructor(encoder) {
        this.encoder = encoder;
    }

    encodeVault(vault) {
        const reuseBasePairs = this.encoder.multiReuse(vault);
        const ngrams = this.extractNgrams(vault);

        const codes = []
        vault.forEach((pw, i) => {
            const base_idx = this.encoder.reuseCheck(i, reuseBasePairs);
            if (base_idx === null) {
                const rules = this.encoder.sppmParse(pw);
                const code = this.encoder.sppmEncode(rules, ngrams);
                codes.push(code);
            } else {
                const bw = vault[base_idx];
                const rules = this.encoder.prpmParse(bw, pw);
                const code = this.encoder.prpmEncode(bw, rules);
                codes.push(code);
            }
        });

        return [reuseBasePairs, codes, ngrams];
    }

    decodeVault(reuseBasePairs, codes, ngrams) {
        const vault = [];

        codes.forEach((code, i) => {
            const base_idx = this.encoder.reuseCheck(i, reuseBasePairs);
            if (base_idx === null) {
                const rules = this.encoder.sppmDecode(code, ngrams, ngrams[i][1]);
                const pw = this.encoder.sppmGenerate(rules);
                vault.push(pw);
            } else {
                const bw = vault[base_idx];
                const rules = this.encoder.prpmDecode(bw, code);
                const pw = this.encoder.prpmGenerate(bw, rules);
                vault.push(pw);
            }
        });
        return vault;
    }

    async encryptVault(cryptoKey, counter, vault) {
        const [reuseBasePairs, codes, ngrams] = this.encodeVault(vault);
        const ngramsCipher = await this.encryptAdaptive(cryptoKey, counter, ngrams);

        const vaultCipher = [];
        for (let i = 0; i < codes.length; i++) {
            const cipher = await Crypto.encrypt(cryptoKey, counter, codes[i]);
            vaultCipher.push(cipher);
        }
        return [reuseBasePairs, vaultCipher, ngramsCipher];
    }

    async decryptVault(cryptoKey, counter, reuseBasePairs, ciphers) {
        const [vaultCipher, ngramsCipher] = ciphers;
        const codes = [];
        for (let i = 0; i < vaultCipher.length; i++) {
            const code = await Crypto.decrypt(cryptoKey, counter, vaultCipher[i]);
            codes.push(code);
        }
        const ngrams = await this.decryptAdaptive(cryptoKey, counter, ngramsCipher);
        const vault = this.decodeVault(reuseBasePairs, codes, ngrams);
        return [vault, ngrams];
    }

    async addPw(cryptoKey, counter, reuseBasePairs, ciphers, pw) {
        const [vault, ngrams] = await this.decryptVault(cryptoKey, counter, reuseBasePairs, ciphers);
        vault.push(pw);
        const ngram = [pw.length, pw[0]];
        ngrams.push(ngram);
        reuseBasePairs = this.encoder.multiReuse(vault);
        const i = vault.length - 1;
        const base_idx = this.encoder.reuseCheck(i, reuseBasePairs);
        const [vaultCipher, ngramsCipher] = ciphers;
        if (base_idx === null) {
            const rules = this.encoder.sppmParse(pw);
            const code = this.encoder.sppmEncode(rules, ngrams);
            const cipher = await Crypto.encrypt(cryptoKey, counter, code);
            vaultCipher.push(cipher);
        } else {
            const bw = vault[base_idx];
            const rules = this.encoder.prpmParse(bw, pw);
            const code = this.encoder.prpmEncode(bw, rules);
            const cipher = await Crypto.encrypt(cryptoKey, counter, code);
            vaultCipher.push(cipher);
        }
        const code = this.encodeNgram(ngram);
        const cipher = await Crypto.encrypt(cryptoKey, counter, code);
        ngramsCipher.push(cipher);

        return [reuseBasePairs, vaultCipher, ngramsCipher];
    }

    async decryptPw(cryptoKey, counter, reuseBasePairs, i, ciphers) {
        const [vaultCipher, ngramsCipher] = ciphers;
        const ngrams = await this.decryptAdaptive(cryptoKey, counter, ngramsCipher);
        const base_idx = this.encoder.reuseCheck(i, reuseBasePairs);
        let pw = ''
        let code, cipher, rules;
        if (base_idx == null) {
            cipher = vaultCipher[i];
            code = await Crypto.decrypt(cryptoKey, counter, cipher);
            rules = this.encoder.sppmDecode(code, ngrams, ngrams[i][1]);
            pw = this.encoder.sppmGenerate(rules);
        }
        else {
            cipher = vaultCipher[base_idx];
            code = await Crypto.decrypt(cryptoKey, counter, cipher);
            rules = this.encoder.sppmDecode(code, ngrams, ngrams[base_idx][1]);
            const bw = this.encoder.sppmGenerate(rules);
            cipher = vaultCipher[i];
            code = await Crypto.decrypt(cryptoKey, counter, cipher);
            rules = this.encoder.prpmDecode(bw, code);
            pw = this.encoder.prpmGenerate(bw, rules);
        }
        return pw;
    }

    extractNgrams(vault) {
        const ngrams = [];
        for (let i = 0; i < vault.length; i++) {
            const length = vault[i].length;
            const next = vault[i][0]
            ngrams.push([length, next])
        }
        return ngrams;
    }

    encodeNgram(ngram) {
        const [length, next] = ngram;
        const lenIdx = this.encoder.len2idx[length];
        const codes = [this.encoder.dte.encode(lenIdx, this.encoder.length_cdf)];

        let cdf = this.encoder.uniform_chars_cdf;
        const prev = this.encoder.start.repeat(this.encoder.order);
        const prevIdx = prevToIndex(prev, this.encoder.order, this.encoder.charset);
        if (this.encoder.sppm[length] && this.encoder.sppm[length][prevIdx]) {
            const pdf = [];
            for (let c of this.encoder.charset) {
                pdf.push((this.encoder.sppm[length][prevIdx][c] || 0) + this.encoder.pseudocount);
            }
            cdf = this.encoder.pdf2cdf(pdf);
        }
        const nextIdx = this.encoder.charset.indexOf(next);
        codes.push(this.encoder.dte.encode(nextIdx, cdf));

        return codes;
    }

    decodeNgram(code) {
        const lenIdx = this.encoder.dte.decode(code[0], this.encoder.length_cdf);
        const length = this.encoder.idx2len[lenIdx];
        const prev = this.encoder.start.repeat(this.encoder.order);
        const prevIdx = prevToIndex(prev, this.encoder.order, this.encoder.charset);

        let cdf = this.encoder.uniform_chars_cdf;
        if (this.encoder.sppm[length] && this.encoder.sppm[length][prevIdx]) {
            const pdf = [];
            for (let c of this.encoder.charset) {
                pdf.push((this.encoder.sppm[length][prevIdx][c] || 0) + this.encoder.pseudocount);
            }
            cdf = this.encoder.pdf2cdf(pdf);
        }
        const nextIdx = this.encoder.dte.decode(code[1], cdf);
        const next = this.encoder.charset[nextIdx];
        return [length, next];
    }

    async encryptAdaptive(cryptoKey, counter, ngrams) {
        const codes = []
        for (let i = 0; i < ngrams.length; i++) {
            codes.push(this.encodeNgram(ngrams[i]));
        }
        const ciphers = [];
        for (let i = 0; i < codes.length; i++) {
            const cipher = await Crypto.encrypt(cryptoKey, counter, codes[i]);
            ciphers.push(cipher);
        }
        return ciphers;
    }

    async decryptAdaptive(cryptoKey, counter, ciphers) {
        const codes = [];
        for (let i = 0; i < ciphers.length; i++) {
            const code = await Crypto.decrypt(cryptoKey, counter, ciphers[i]);
            codes.push(code);
        }
        const ngrams = [];
        for (let i = 0; i < codes.length; i += 1) {
            ngrams.push(this.decodeNgram(codes[i]));
        }
        return ngrams;
    }
}

export { DTE, Encoder, VaultGuard };