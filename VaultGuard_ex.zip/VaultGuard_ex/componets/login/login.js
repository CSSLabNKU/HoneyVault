import { Crypto } from "../utils/crypto.js";
import { Storage } from "../utils/storage.js";
import { PasswordTools } from "../utils/password.js";
import { notifications } from "../utils/notification.js";


$(document).ready(function () {

    chrome.runtime.sendMessage({ action: 'popup_opened' }, (response) => {
        if (chrome.runtime.lastError) {
            console.warn('[Login] Sending message error:', chrome.runtime.lastError.message);
        } else {
            console.log('[Login] Background script response:', response);
        }
    });

    Storage.sessionGet('current').then((email) => {
        if (email) {
            window.location.href = `../manager/manager.html`;
        }
    });

    let registeredUsers = [];
    Storage.localGet('registeredUsers')
        .then((users) => {
            registeredUsers = users || [];
            if (registeredUsers.length === 0) {
                return Storage.localSave('registeredUsers', []);
            }
        });

    $('#email').on('input', function () {
        const email = $(this).val().trim();        
        if (!registeredUsers.includes(email)) {
            $(this).val('');
            $(this).focus();
            notifications.showError('This email is not registered! Please use a different email or sign up.');
        }
    });

    let hintedColorIndex;
    $('#password').on('input', function() {
        const password = $(this).val().trim();
        hintedColorIndex = PasswordTools.updateHintedColor(password);
        $('#color-hint').attr('class', `color-hint color-hint-${hintedColorIndex}`);
    });

    $('.visibility-toggle').on('click', function() {
        const passwordInput = document.getElementById('password');
        PasswordTools.togglePasswordVisibility(passwordInput, this);
    });

    $('#login-form').on('submit', function(event) {
        event.preventDefault();
        const submitBtn = $('.btn');
        submitBtn.prop('disabled', true).text('Processing...');

        const password = $('#password').val().trim();
        const email = $('#email').val().trim();
        if (!password || !email) {
            alert('⚠️ The email address and password cannot be empty!');
            submitBtn.prop('disabled', false).text('LOG IN');
            return;
        }

        Storage.localGet(email).then(async (accounts) => {
            const salt = new Uint8Array(accounts.salt);
            const cryptoKey = await Crypto.deriveKey(password, salt);
            const keyBufferBase64 = await Crypto.exportKeyAsBase64(cryptoKey);
            const encodedKey = encodeURIComponent(keyBufferBase64);
            const encodedColorIndex = encodeURIComponent(hintedColorIndex);
            Storage.sessionSave('current', email).then(() => {
                window.location.href = `../manager/manager.html?key=${encodedKey}&index=${encodedColorIndex}`;
            });
        });
    });
});
