import { Crypto } from "../utils/crypto.js";
import { Storage } from "../utils/storage.js";
import { PasswordTools } from "../utils/password.js";
import { notifications } from "../utils/notification.js";


$(document).ready(function () {

    let registeredUsers = [];
    Storage.localGet('registeredUsers').then((users) => {
        registeredUsers = users || [];
        if (registeredUsers.length === 0) {
            return Storage.localSave('registeredUsers', []);
        }
    });

    $('#email').on('input', function () {
        const email = $(this).val().trim();        
        if (registeredUsers.includes(email)) {
            $(this).val('');
            $(this).focus();
            notifications.showError('This email is already registered! Please use a different email or back to login.');
        }
    });

    $('#password').on('input', async function() {
        const password = $(this).val().trim();
        await PasswordTools.updatePasswordStrength(password);
        await PasswordTools.updatePasswordBreach(password);
    });

    $('.visibility-toggle').on('click', function() {
        const passwordInput = document.getElementById('password');
        PasswordTools.togglePasswordVisibility(passwordInput, this);
    });

    $('#register-form').on('submit', function(event) {
        event.preventDefault();
        const submitBtn = $('.btn');
        submitBtn.prop('disabled', true).text('Processing...');

        const password = $('#password').val().trim();
        const email = $('#email').val().trim();
        if (!password || !email) {
            alert('⚠️ The email address and password cannot be empty!');
            submitBtn.prop('disabled', false).text('CREATE ACCOUNT');
            return;
        }

        Storage.localSave(email, {
            salt: Array.from(Crypto.generateSalt()),
            counter: Array.from(Crypto.generateCounter()),
            vault: {
                domains: [],
                emails: [],
                ciphers: [[], []],
                is_delete: [],
                reuse_base_pairs: []
            }
        }).then(() => {
            registeredUsers.push(email);
            return Storage.localSave('registeredUsers', registeredUsers);
        }).then(() => {
            const colorIndex = PasswordTools.updateHintedColor(password);
            const colorNames = ['Orange', 'Yellow', 'Green', 'Blue', 'Purple'];
            const colorName = colorNames[colorIndex];

            $('.message-box').css('display', 'block');
            $('body').append('<div class="overlay"></div>');
            $('#color-value').text(`Your hinted color is: ${colorName}`).css('color', `${colorName}`);

            $('.message-close-btn').on('click', function() {
                window.location.href = '../login/login.html';
            });
        }).catch((error) => {
            console.error('Error during registration:', error);
            alert('An error occurred during registration. Please try again.');
            submitBtn.prop('disabled', false).text('CREATE ACCOUNT');
        });
    });
});
