import { Crypto } from "../utils/crypto.js";
import { Storage } from "../utils/storage.js";
import { PasswordTools } from "../utils/password.js";
import { notifications } from "../utils/notification.js";
import { Encoder, VaultGuard } from "../utils/vaultguard.js";

// 数据库配置
const DB_NAME = 'VaultGuardDB';
const DB_VERSION = 1;
const MODEL_STORE = 'modelStore';
const MODEL_KEY = 'model';

let current;
let cryptoKey;
let vaultGuard;

$(document).ready(function () {

    let charset;
    let length_counts;
    let prpm;
    let sppm;
    let encoder;
    
    (async function () {
        current = await Storage.sessionGet('current');
        const urlParams = new URLSearchParams(window.location.search);
        const encodedKey = urlParams.get('key');
        const encodedColorIndex = urlParams.get('index');

        if (encodedKey && encodedColorIndex) {
            cryptoKey = await Crypto.importKeyFromBase64(decodeURIComponent(encodedKey));
            const index = decodeURIComponent(encodedColorIndex);
            $('.color-indicator').css('background-color', `var(--color-hint-${index})`);
            $('#current-user-info .entry-email').text(current);
        } else {
            cryptoKey = await setupMasterPasswordModal(current);
        }

        const modelData = await getModelFromIndexDB();
        if (modelData) {
            charset = modelData.charset;
            length_counts = modelData.length_counts;
            prpm = modelData.prpm;
            sppm = modelData.sppm;
            
            encoder = new Encoder(charset, length_counts, prpm, sppm);
            vaultGuard = new VaultGuard(encoder);

            await loadAccounts(vaultGuard, current, cryptoKey);
        
            console.log('[Manager] Model loaded successfully:', current);
        } else {
            console.error('[Manager] Failed to retrieve model data');
        }
    })();

    $('#logout-btn').off('click').on('click', function() {
        Storage.sessionClear().then(() => {
            window.location.href = '../login/login.html';
        });
    });

    $('#btn-add-account').off('click').on('click', function() {
        $('#account-add-form')[0].reset();
        $('#password-strength').attr('class', 'password-strength');
        $('.password-process-bar').attr('style', '');
        $('#password-strength-text').html('');
        $('#breach-alert').html('');
        $('#account-add-form .btn').prop('disabled', false).text('Save');
        $('#account-add-modal').show();
        $('body').append('<div class="overlay"></div>');
    });

    $('#account-password').off('input').on('input', async function () {
        const password = $(this).val().trim();
        await PasswordTools.updatePasswordStrength(password);
        await PasswordTools.updatePasswordBreach(password);
    });

    $('#close-modal-btn').off('click').on('click', function() {
        $('#account-add-modal').hide();
        $('.overlay').remove();

        $('#account-add-form')[0].reset();
        $('#password-strength').attr('class', 'password-strength');
        $('.password-process-bar').attr('style', '');
        $('#password-strength-text').html('');
        $('#breach-alert').html('');
    });

    $('#account-add-form').off('submit').on('submit', async function(e) {
        e.preventDefault();
        
        const submitBtn = $(this).find('.btn');
        submitBtn.prop('disabled', true).text('Processing...');
        
        const domain = $('#domain').val().trim();
        const email = $('#email').val().trim();
        const password = $('#account-password').val().trim();

        if (!domain || !email || !password) {
            notifications.showError('Please fill in all required fields');
            submitBtn.prop('disabled', false).text('Save');
            return;
        }

        const accounts = await Storage.localGet(current);
        accounts.vault.domains.push(domain);
        accounts.vault.emails.push(email);
        accounts.vault.is_delete.push(false);
        
        const counter = new Uint8Array(accounts.counter);
        let reuseBasePairs = accounts.vault.reuse_base_pairs;
        let ciphers = accounts.vault.ciphers;

        let vaultCipher;
        let ngramsCipher;
        [reuseBasePairs, vaultCipher, ngramsCipher] = await vaultGuard.addPw(cryptoKey, counter, reuseBasePairs, ciphers, password);

        accounts.vault.ciphers = [vaultCipher, ngramsCipher];
        accounts.vault.reuse_base_pairs = reuseBasePairs;

        await Storage.localSave(current, accounts);
        
        $(this)[0].reset();
        $('#password-strength').attr('class', 'password-strength');
        $('.password-process-bar').attr('style', '');
        $('#password-strength-text').html('');
        $('#breach-alert').html('');
        $('#account-add-modal').hide();
        $('.overlay').remove();
        
        if (current && cryptoKey) {
            await loadAccounts(vaultGuard, current, cryptoKey);
        }
    });


    let searchMode = 'email';
    $('#search-mode-select').off('change').on('change', function() {
        searchMode = $(this).val();
        $('#search-bar').val('');
        if (current && cryptoKey) {
            loadAccounts(vaultGuard, current, cryptoKey);
        }
    });
    
    $('#search-bar').off('input').on('input', function() {
        const keyword = $(this).val().trim();
        if (current && cryptoKey) {
            loadAccounts(vaultGuard, current, cryptoKey, searchMode, keyword);
        }
    });
});

function setupMasterPasswordModal(current) {
    return new Promise((resolve, reject) => {
        $('#master-input-modal').show();
        $('body').append('<div class="overlay"></div>');
        
        $('#master-password').off('input').on('input', function () {
            const password = $(this).val().trim();
            const index = PasswordTools.updateHintedColor(password);
            $('#color-hint').attr('class', `color-hint color-hint-${index}`);
        });
        
        $('.visibility-toggle').off('click').on('click', function () {
            const passwordInput = document.getElementById('master-password');
            PasswordTools.togglePasswordVisibility(passwordInput, this);
        });
        
        $('#master-input-form').off('submit').on('submit', function (e) {
            e.preventDefault();
            const submitBtn = $(this).find('.btn');
            submitBtn.prop('disabled', true).text('Processing...');

            const password = $('#master-password').val().trim();
            if (!password) {
                submitBtn.prop('disabled', false).text('Confirm');
                return;
            }

            Storage.localGet(current).then(async (accounts) => {
                const salt = new Uint8Array(accounts.salt);
                const cryptoKey = await Crypto.deriveKey(password, salt);
                    
                $('#master-input-modal').hide();
                $('.overlay').remove();
                    
                submitBtn.prop('disabled', false).text('Confirm');
                const index = PasswordTools.updateHintedColor(password);
                $('.color-indicator').css('background-color', `var(--color-hint-${index})`);
                $('#current-user-info .entry-email').text(current);

                resolve(cryptoKey);
            });
        });
    });
}

async function loadAccounts(vaultGuard, current, cryptoKey, searchMode=null, keyword=null) {
    const accounts = await Storage.localGet(current);
    if (!accounts || !accounts.vault) {
        return;
    }

    const counter = new Uint8Array(accounts.counter);
    const { domains, emails, ciphers, is_delete, reuse_base_pairs } = accounts.vault;
    const [vault, ngrams] = await vaultGuard.decryptVault(cryptoKey, counter, reuse_base_pairs, ciphers);

    let entries = [];
    for (let i = 0; i < domains.length; i++) {
        if (!is_delete[i]) {
            entries.push({
                domain: domains[i],
                email: emails[i],
                password: vault[i],
                id: i
            });
        }
    }

    if (searchMode && keyword) {
        entries = entries.filter(entry => {
            if (searchMode === 'email') {
                return entry.email.toLowerCase().includes(keyword.toLowerCase());
            } else if (searchMode === 'domain') {
                return entry.domain.toLowerCase().includes(keyword.toLowerCase());
            }
            return true;
        });
    }
    
    await displayEntries(entries, current);
}

async function displayEntries(entries) {
    const container = $('#entry-container');
    container.css('display', 'block');
    container.empty();
    
    for (const entry of entries) {
        const accountEntry = `
            <div class="entry" data-id="${entry.id}">
                <div class="entry-text">
                    <div class="entry-domain">${entry.domain}</div>
                    <div class="entry-email">${entry.email}</div>
                    <div class="entry-password">${entry.password}</div>
                </div>
                <div class="entry-options">
                    <button class="account-btn" title="Copy email"></button>
                    <button class="password-btn" title="Copy password"></button>
                    <button class="edit-btn" title="Edit"></button>
                    <button class="delete-btn" title="Delete"></button>
                </div>
            </div>
        `;
        
        container.append(accountEntry);
        
        container.find('.entry:last-child .account-btn').off('click').on('click', function() {
            navigator.clipboard.writeText(entry.email)
                .then(() => showCopyFeedback(this));
        });
        
        container.find('.entry:last-child .password-btn').off('click').on('click', function() {
            navigator.clipboard.writeText(entry.password)
                .then(() => showCopyFeedback(this));
        });

        container.find('.entry:last-child .delete-btn').off('click').on('click', async function () {
            const current = await Storage.sessionGet('current');
            const accounts = await Storage.localGet(current);
            const index = parseInt($(this).closest('.entry').data('id'));

            if (index !== -1 && !isNaN(index)) {
                accounts.vault.is_delete[index] = true;
                $(this).closest('.entry').remove();
                await Storage.localSave(current, accounts);
            }
        });

        $('#account-password').off('input').on('input', async function () {
            const password = $(this).val().trim();
            await PasswordTools.updatePasswordStrength(password);
            await PasswordTools.updatePasswordBreach(password);
        });
        
        $('#close-modal-btn').off('click').on('click', function() {
            $('#account-add-modal').hide();
            $('.overlay').remove();

            $('#account-add-form')[0].reset();
            $('#password-strength').attr('class', 'password-strength');
            $('.password-process-bar').attr('style', '');
            $('#password-strength-text').html('');
            $('#breach-alert').html('');
        });
        
        container.find('.entry:last-child .edit-btn').off('click').on('click', async function() {
            // 重置表单和按钮状态
            $('#account-add-form')[0].reset();
            $('#account-add-form .btn').prop('disabled', false).text('Save');
            
            // 显示模态框
            $('#account-add-modal').show();
            $('body').append('<div class="overlay"></div>');

            // 填充数据
            $('#domain').val(entry.domain);
            $('#email').val(entry.email);
            $('#account-password').val(entry.password);

            // 更新密码强度
            await PasswordTools.updatePasswordStrength(entry.password);
            await PasswordTools.updatePasswordBreach(entry.password);

            // 标记原条目为删除
            const current = await Storage.sessionGet('current');
            const accounts = await Storage.localGet(current);
            const index = parseInt($(this).closest('.entry').data('id'));

            if (index !== -1) {
                accounts.vault.is_delete[index] = true;
                await Storage.localSave(current, accounts);
            }
        });
    }
}

function showCopyFeedback(button) {
    const entry = $(button).closest('.entry')[0];
    entry.style.transition = 'transform 0.2s';
    entry.style.transform = 'translateX(-120px)';
    let feedback = button.querySelector('.copy-feedback');
    if (!feedback) {
        feedback = document.createElement('span');
        feedback.className = 'copy-feedback';
        feedback.style.position = 'absolute';
        feedback.style.right = '-100px';
        feedback.style.top = '50%';
        feedback.style.transform = 'translateY(-50%)';
        feedback.style.background = '#e0ffe0';
        feedback.style.color = '#2a7b2a';
        feedback.style.padding = '4px 12px';
        feedback.style.borderRadius = '6px';
        feedback.style.fontSize = '13px';
        feedback.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08)';
        feedback.style.zIndex = '10';
        entry.style.position = 'relative';
        entry.appendChild(feedback);
    }
    feedback.textContent = 'Copied!';
    feedback.style.display = 'inline-block';
    setTimeout(() => {
        entry.style.transform = 'translateX(0)';
        feedback.style.display = 'none';
    }, 500);
}

async function getModelFromIndexDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
            const db = request.result;
            const transaction = db.transaction([MODEL_STORE], 'readonly');
            const store = transaction.objectStore(MODEL_STORE);
            const getRequest = store.get(MODEL_KEY);
            getRequest.onerror = () => reject(getRequest.error);
            getRequest.onsuccess = () => resolve(getRequest.result);
        };
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(MODEL_STORE)) {
                db.createObjectStore(MODEL_STORE);
            }
        };
    });
}