# VaultGuard

The Chrome browser extension implementation of our honey vault scheme.

## Deployment process

1. Clone or download the repository to the local computer
2. Type 'chrome://extensions/' in the Chrome address bar
3. Enable "Developer Mode"
4. Click on "Load Unzipped Extension"
5. Select the project directory
6. The extension installation is completed
