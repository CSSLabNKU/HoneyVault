importScripts('../componets/utils/pako.min.js');

const DB_NAME = 'VaultGuardDB';
const DB_VERSION = 1;
const MODEL_STORE = 'modelStore';
const MODEL_KEY = 'model';

class IndexDBManager {
    static async openDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
            
            request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(MODEL_STORE)) {
                db.createObjectStore(MODEL_STORE);
            }
            };
        });
    }

    static async storeModel(modelData) {
        const db = await this.openDB();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction([MODEL_STORE], 'readwrite');
            const store = transaction.objectStore(MODEL_STORE);
            const request = store.put(modelData, MODEL_KEY);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    }

    static async getModel() {
        const db = await this.openDB();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction([MODEL_STORE], 'readonly');
            const store = transaction.objectStore(MODEL_STORE);
            const request = store.get(MODEL_KEY);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    }

    static async checkModelExists() {
        try {
            const model = await this.getModel();
            return model !== undefined;
        } catch (error) {
            console.error('[IndexDB] Check model existence error:', error);
            return false;
        }
    }
}

class ModelProcessor {
    static async fetchModelFile() {
        const modelURL = chrome.runtime.getURL('assets/model/model.json.gz');
        const response = await fetch(modelURL);
        if (!response.ok) {
            throw new Error(`Fetching model file failed: ${response.status}`);
        }
        return await response.arrayBuffer();
    }

    static decompressModel(compressedData) {
        try {
            const uint8Array = new Uint8Array(compressedData);
            const decompressed = pako.ungzip(uint8Array, { to: 'string' });
            return JSON.parse(decompressed);
        } catch (error) {
            throw new Error(`Decompression failed: ${error.message}`);
        }
    }

    static async processModelFile(context = 'Unknown') {
        const startTime = performance.now();
        console.log(`[${context}] Starting model file processing...`);

        try {
            // Step 1: Fetch compressed file
            const fetchStartTime = performance.now();
            const compressedData = await this.fetchModelFile();
            const fetchTime = performance.now() - fetchStartTime;
            console.log(`[${context}] Fetching compressed file completed, duration: ${(fetchTime / 1000).toFixed(3)} seconds`);

            // Step 2: Decompress
            const decompressStartTime = performance.now();
            const modelData = this.decompressModel(compressedData);
            const decompressTime = performance.now() - decompressStartTime;
            console.log(`[${context}] Decompression completed, duration: ${(decompressTime / 1000).toFixed(3)} seconds`);

            // Step 3: Store to IndexDB
            const storeStartTime = performance.now();
            await IndexDBManager.storeModel(modelData);
            const storeTime = performance.now() - storeStartTime;
            console.log(`[${context}] Upload completed, duration: ${(storeTime / 1000).toFixed(3)} seconds`);

            // Total time
            const totalTime = performance.now() - startTime;
            console.log(`[${context}] Total duration: ${(totalTime / 1000).toFixed(3)} seconds`);
        } catch (error) {
            console.error(`[${context}] Error processing model file:`, error);
            throw error;
        }
    }
}

chrome.runtime.onInstalled.addListener(async (details) => {
    if (details.reason === 'install') {
        console.log('[Extension install] VaultGuard is installed');

        try {
            await ModelProcessor.processModelFile('Extension install');
            
            const iconUrl = chrome.runtime.getURL('assets/icons/icon48.png');
            
            chrome.notifications.create({
                type: 'basic',
                iconUrl: iconUrl,
                title: 'VaultGuard',
                message: 'Model uploaded successfully! VaultGuard is ready to use.'
            }, (notificationId) => {
                if (chrome.runtime.lastError) {
                    console.error('[Extension install] Notification creation error:', chrome.runtime.lastError);
                }
            });

        } catch (error) {
            console.error('[Extension install] Error processing model file:', error);
            const iconUrl = chrome.runtime.getURL('assets/icons/icon48.png');
            
            chrome.notifications.create({
                type: 'basic',
                iconUrl: iconUrl,
                title: 'VaultGuard',
                message: 'Model upload failed, please check your network connection and try again.'
            }, (notificationId) => {
                if (chrome.runtime.lastError) {
                    console.error('[Extension install] Error notification creation error:', chrome.runtime.lastError);
                }
            });
        }
    }
});

chrome.action.onClicked.addListener(async () => {
    await checkAndLoadModel('Extension open');
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'popup_opened') {
        checkAndLoadModel('Extension popup opened').then(() => {
            sendResponse({ status: 'model_checked' });
        }).catch((error) => {
            console.error('[Background] Processing popup_opened message error:', error);
            sendResponse({ status: 'error', error: error.message });
        });
        return true;
    }
});

async function checkAndLoadModel(context) {
    console.log(`[${context}] Checking model file in IndexDB...`);

    try {
        const modelExists = await IndexDBManager.checkModelExists();

        if (modelExists) {
            console.log(`[${context}] Model file exists, no need to re-upload.`);
            // // Read model data from IndexDB
            // console.log(`[${context}] Reading model data from IndexDB...`);
            // const readStartTime = performance.now();
            // const modelData = await IndexDBManager.getModel();
            // const readTime = performance.now() - readStartTime;
            // console.log(`[${context}] Reading completed, duration: ${(readTime / 1000).toFixed(3)} seconds`);
            
        } else {
            console.log(`[${context}] Model file not found, starting extraction and upload...`);
            await ModelProcessor.processModelFile(context);
        }
    } catch (error) {
        console.error(`[${context}] Error checking and loading model:`, error);
    }
}

console.log('[Background] VaultGuard Service Worker is running');